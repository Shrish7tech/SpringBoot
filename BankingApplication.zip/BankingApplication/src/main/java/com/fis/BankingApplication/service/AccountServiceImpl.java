package com.fis.BankingApplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.BankingApplication.model.Accounts;
import com.fis.BankingApplication.repo.AccountRepo;

@Service
@Transactional
public class AccountServiceImpl implements AccountService{

	@Autowired
	AccountRepo repo;
	@Override
	public String addAccount(Accounts account) {
		// TODO Auto-generated method stub
		repo.addAccount(account);
		return null;
	}

	@Override
	public Accounts getAccount(long accNo) {
		// TODO Auto-generated method stub
		return repo.getAccount(accNo);
	}

	@Override
	public List<Accounts> getAllAccount() {
		// TODO Auto-generated method stub
		return repo.getAllAccount();
	}

	@Override
	public String updateAccount(Accounts acc) {
		// TODO Auto-generated method stub
		return repo.updateAccount(acc);
	}

	@Override
	public String deleteAccount(int accNo) {
		// TODO Auto-generated method stub
		repo.deleteAccount(accNo);
		return "Account Deleted";
	}

	@Override
	public List<Accounts> getAllAccountsByBalanceRange(double minBal, double maxBal) {
		// TODO Auto-generated method stub
		return repo.getAllAccountsByBalanceRange(minBal,maxBal);

	}

}
