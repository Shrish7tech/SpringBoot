package com.fis.BankingApplication.model;

public class Customer {

}
