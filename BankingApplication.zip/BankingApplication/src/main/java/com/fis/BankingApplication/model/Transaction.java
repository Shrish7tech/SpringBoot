package com.fis.BankingApplication.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

 

import com.fasterxml.jackson.annotation.JsonFormat;
@Entity
@Table(name="transactions_information")
public class Transaction {
	@Id
	private int transId;
	private long accNoFrom;
	private long accNoTo;
	private double amount;
	@JsonFormat(pattern = "yyyy-MM-dd")
	private Date dateOfTrans;
	private String transType;
	
	
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public long getAccNoFrom() {
		return accNoFrom;
	}
	public void setAccNoFrom(long accNoFrom) {
		this.accNoFrom = accNoFrom;
	}
	public long getAccNoTo() {
		return accNoTo;
	}
	public void setAccNoTo(long accNoTo) {
		this.accNoTo = accNoTo;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Date getDateOfTrans() {
		return dateOfTrans;
	}
	public void setDateOfTrans(Date dateOfTrans) {
		this.dateOfTrans = dateOfTrans;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	
	
	public Transaction(int transId, long accNoFrom, long accNoTo, double amount, Date dateOfTrans, String transType) {
		super();
		this.transId = transId;
		this.accNoFrom = accNoFrom;
		this.accNoTo = accNoTo;
		this.amount = amount;
		this.dateOfTrans = dateOfTrans;
		this.transType = transType;
	}
	public Transaction() {
		super();
	}
}