package com.fis.BankingApplication.service;

import java.util.List;

import com.fis.BankingApplication.model.Transaction;

public interface TransactionService {
	public abstract String withdrawFromBalance(long acc, double withdrawAmount);

	public abstract String depositIntoBalance(long acc, double depositAmount);
	
	public abstract String fundTransferNEFT(Transaction transaction); 

	public abstract String fundTransferRTGS(Transaction transaction);
	
	public abstract List<Transaction> getAllTransOfAcc(long getAcc);

}
