package com.fis.BankingApplication.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.fis.BankingApplication.model.Accounts;
import com.fis.BankingApplication.model.Transaction;



@Repository
public class TransactionRepoImpl implements TransactionRepo{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public String withdrawFromBalance(long accNo, double withdrawAmount) {
		// TODO Auto-generated method stub
		Accounts account=entityManager.find(Accounts.class, accNo);
		if(account!=null && withdrawAmount<account.getBalance())
		{
			double c_bal=account.getBalance();
			double u_bal=c_bal-withdrawAmount;
			account.setBalance(u_bal);
			entityManager.merge(account);
		}
	    return" Amount is Withdrawn";

	}

	@Override
	public String depositIntoBalance(long accNo, double depositAmount) {
		// TODO Auto-generated method stub
		//TypedQuery<Accounts> query =entityManager.createQuery("Select a from Accounts a",Accounts.class);
		Accounts account=entityManager.find(Accounts.class, accNo);
		if(account!=null && depositAmount>0)
		{
			double c_bal=account.getBalance();
			double u_bal=c_bal+depositAmount;
			account.setBalance(u_bal);
			entityManager.merge(account);
			entityManager.persist(account);
		}
	    return" Amount is deposited";
	}

	@Override
	public String fundTransferNEFT(Transaction transaction) {
		// TODO Auto-generated method stub
		Accounts acc1 = new Accounts();
		Accounts acc2 = new Accounts();
		acc1 = entityManager.find(Accounts.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Accounts.class, transaction.getAccNoTo());
		acc1.setBalance(acc1.getBalance() - transaction.getAmount());
		acc2.setBalance(acc2.getBalance() + transaction.getAmount());
		entityManager.persist(transaction);
		return "NEFT Transaction performed Successfully...";
	
	}

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		// TODO Auto-generated method stub
		Accounts acc1 = new Accounts();
		Accounts acc2 = new Accounts();
		acc1 = entityManager.find(Accounts.class, transaction.getAccNoFrom());
		acc2 = entityManager.find(Accounts.class, transaction.getAccNoTo());
		acc1.setBalance(acc1.getBalance() - transaction.getAmount());
		acc2.setBalance(acc2.getBalance() + transaction.getAmount());
		entityManager.persist(transaction);
		return "RTGS Transaction performed Successfully...";

	}

	@Override
	public List<Transaction> getAllTransOfAcc(long getAcc) {
		// TODO Auto-generated method stub
		TypedQuery<Transaction> query = entityManager.createQuery("select trans from Transaction trans where trans.accNoTo = ?1 or trans.accNoFrom = ?1", Transaction.class);
		query.setParameter(1, getAcc);
		return query.getResultList();
		
	}


}
