package com.fis.BankingApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fis.BankingApplication.model.Accounts;
import com.fis.BankingApplication.service.AccountService;
import com.fis.productmanagement.model.Product;

//
//{
//
//    "accNo":101,
//	"custName":"Shrish",
//	"email":"shrish680@gmail.com",
//	"password":"Shr@123",
//	"mobile":9305665227,
//	"accType":"Saving",
//	"branch":"Kalyanpur",
//	"balance":10000,
//	"aadhar":54672345,
//	"dob":"07/01/2001"
//}
//
//{
//  "accNo":102,
//	"custName":"Ram",
//	"email":"Ram@gmail.com",
//	"password":"Ram@123",
//	"mobile":8174049723,
//	"accType":"Saving",
//	"branch":"Awadh",
//	"balance":56000,
//	"aadhar":67893420,
//	"dob":"09/04/2000"
//}
@RestController
@RequestMapping("/accounts")
public class AccountController {
	@Autowired
	AccountService service;
		@PostMapping("/addAccount") // http://localhost:8080/accounts/addAccount
		public String saveAccount(@RequestBody Accounts acc) {
			service.addAccount(acc);
			return "Account added successfully";
		}
		
		
		@GetMapping("/getAccount/{accNo}") // http://localhost:8080/accounts/getAccount/103
		public Accounts getAccount(@PathVariable("accNo") int accNo) {
			return service.getAccount(accNo);
		}

		@GetMapping("/getAllAccount") // http://localhost:8080/accounts/getAllAccount
		public List<Accounts> getAllAccount() {
			return service.getAllAccount();
		}
		
		@PutMapping("/updateAccount") // http://localhost:8080/accounts/updateAccount
		public String updateAccount(@RequestBody Accounts account) {
			return service.updateAccount(account);
		}

		@DeleteMapping("/deleteAccount/{acc}") // http://localhost:8080/accounts/deleteAccount/103
		public String deleteAccount(@PathVariable("acc") int accNo) {
			return service.deleteAccount(accNo);
		}
		

}


