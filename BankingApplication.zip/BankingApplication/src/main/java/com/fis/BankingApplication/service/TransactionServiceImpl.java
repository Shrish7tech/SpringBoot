package com.fis.BankingApplication.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fis.BankingApplication.model.Transaction;
import com.fis.BankingApplication.repo.TransactionRepo;

@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private TransactionRepo trepo;
	@Override
	public String withdrawFromBalance(long acc, double withdrawAmount) {
		// TODO Auto-generated method stub
		return trepo.withdrawFromBalance(acc, withdrawAmount);
	}

	@Override
	public String depositIntoBalance(long acc, double depositAmount) {
		// TODO Auto-generated method stub
		return trepo.depositIntoBalance(acc, depositAmount);

	}

	@Override
	public String fundTransferNEFT(Transaction transaction) {
		// TODO Auto-generated method stub
		return trepo.fundTransferNEFT(transaction);
		
	}

	@Override
	public String fundTransferRTGS(Transaction transaction) {
		// TODO Auto-generated method stub
		return trepo.fundTransferRTGS(transaction);
	}

	@Override
	public List<Transaction> getAllTransOfAcc(long getAcc) {
		// TODO Auto-generated method stub
		return trepo.getAllTransOfAcc(getAcc);
	}

	

}
