package com.fis.BankingApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.fis.BankingApplication.model.Transaction;
import com.fis.BankingApplication.service.TransactionService;



@RestController
@RequestMapping("/transactions") 
public class TransactionController {
	
	@Autowired
	private TransactionService tservice;
	
	@PutMapping("/withdrawFromBalance/{accno}/{amount}") // http://localhost:8080/transactions/withdrawFromBalance/101/40000
	public String withdrawFromBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double withdrawAmount) {
		return tservice.withdrawFromBalance(getAcc, withdrawAmount);
	}

	@PutMapping("/depositIntoBalance/{accno}/{amount}") // http://localhost:8080/transactions/depositIntoBalance/102/2100
	public String depositIntoBalance(@PathVariable("accno") long getAcc , @PathVariable("amount") double depositAmount) {
		return tservice.depositIntoBalance(getAcc, depositAmount);
	}
	@GetMapping("/getAllTransOfAcc") // http://localhost:8080/accounts/getAllTransOfAcc
	public List<Transaction> getAllTransOfAcc(@RequestBody long getAcc){
		return tservice.getAllTransOfAcc(getAcc);
	}

	@PutMapping("/transactions/fundTransfer/{transType}/") // http://localhost:8080/accounts/transactions/fundTransfer/transType
	public String fundTransferType (@PathVariable("transType") String transType, @RequestBody Transaction transaction) {
		if (transType.equalsIgnoreCase("neft")) {
			return tservice.fundTransferNEFT(transaction);
		}
		else if (transType.equalsIgnoreCase("rtgs")) {
			return tservice.fundTransferRTGS(transaction);
		}
		else {
			return "Wrong Transaction Type...";
		}
	}


	
}
